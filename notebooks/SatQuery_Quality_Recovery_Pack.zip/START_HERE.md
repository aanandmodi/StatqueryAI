# SatQuery quality recovery — start with pending 04

These are separate Kaggle training jobs, not new training of the Qwen LoRA. Nothing is uploaded
to Hugging Face automatically. Your original downloads in `upgrade/` are preserved.
Only notebooks and their build/test helpers were added; the website and local backend were not changed.

## What your saved results show

| Specialist | Saved development result | Existing acceptance target | Action |
|---|---|---|---|
| Qwen | VQA exact match 0.57, grounding mean IoU 0.381 on your 200-row validation sample | Report measured task metrics; this is not a universal accuracy score | Keep 01 evidence; run the existing 05 final-test notebook when ready |
| Vegetation/water | Mean IoU 0.350, forest IoU 0.249 | Mean IoU ≥0.45; water, forest and agriculture each ≥0.35 | 02R starts from your saved SegFormer weights |
| Temporal | Validation answer accuracy 0.713; mask IoU 0.397 | Answer accuracy ≥0.60 and mask IoU ≥0.40 on validation and test | 03R transfers your trained encoder/answer head and adds a finer decoder |
| Optical/SAR flood | Training not yet completed | Flood IoU ≥0.50; fused validation no worse than either single-modality ablation | Run 04 now |

These are prototype acceptance gates, not assurances of operational precision. A new experiment
can fail. Gates are not reduced, and failed outputs are not automatically promoted to serving.

## Recommended order

1. **04_Train_Optical_SAR_Flood_Masks.ipynb** — finish the outstanding specialist first.
2. **02R_Improve_Vegetation_Water.ipynb** — improve forest segmentation from your saved weights.
3. **03R_Improve_Temporal_Change.ipynb** — improve temporal masks from your saved weights.
4. Existing **05_Qwen_Final_Test.ipynb** in `notebooks/kaggle-run-all/`, with the full 01 output.
   Do not rerun it if you already completed that frozen final test.
5. **06R_All_Models_Ngrok_Server.ipynb** — only after all three specialist gates pass.

Do not run all three training jobs in one session or alongside the inference server. Each notebook
is standalone, but its input attachments must be in place before **Run All**.

## Kaggle setup and attachments

For every training job, import the `.ipynb` into a fresh Kaggle notebook, enable Internet and a CUDA
GPU (T4/P100), and then Run All. TPU is a different accelerator and is not supported by this code.
Check available quota in your account; availability and allowed duration can change. No paid
endpoint is created and no local GPU training is required.

| Notebook | Attach before Run All | Downloads automatically | Download before stopping |
|---|---|---|---|
| 04 | Nothing for the first run | Official Sen1Floods11 optical/SAR/hand-labelled flood triplets and TerraMind tiny | `04_fusion_inference.zip`, `04_fusion_resume.zip` |
| 02R | Entire extracted `upgrade/02_segmentation_inference` folder | Official LoveDA train/validation archives | `02R_segmentation_inference.zip`, `02R_resume.zip` |
| 03R | Entire extracted `upgrade/03_change_inference` folder | Pinned CDVQA annotations and processed SECOND image/label archive | `03R_change_inference.zip`, `03R_resume.zip` |
| 06R | Exactly one **passing inference export** each from 02R, 03R and 04 | Existing pinned Qwen base + LoRA | Connection settings; keep this attended session running for the demo |

To attach a local folder, upload its contents as a **private Kaggle Dataset**, then add it using
**Add Input**. Alternatively attach the saved Notebook Output. Preserve the nested files and names;
the notebook discovers them under `/kaggle/input`. An unextracted ZIP alone is not sufficient.
For 02R/03R, the parent checkpoint is checked against the exact SHA of the weights you downloaded.
Attach the whole original inference folder, not just `model.safetensors`.

02R and 03R warm-start a **new experiment**, rather than pretending to resume missing optimizer
state from your earlier run. They preserve original train/validation membership; test images are
never added to training. LoveDA still uses 70% of its official training split, not 70% of all data.

## What changed

### 02R: vegetation/water

- Trained SegFormer B0 weights, not a fresh randomly initialized segmentation head.
- More forest-containing training views and a mixture of full-scene and native-scale crops.
- Lower learning rate, warm-up and cosine decay.
- Best-checkpoint selection considers all declared class gates, not only average IoU.
- Microbatch one, accumulation eight, zero workers, streaming confusion-matrix validation.
- Re-evaluates the parent and preserves it if the selected recovery model is worse by the declared
  selection score. The parent's failed status is not changed simply because it was preserved.
- Exports per-scene scores and labelled jury previews alongside model files.

LoveDA validation is a development set reused for model selection; its unavailable public test
labels are not invented. All reported metrics use the same 384px evaluation protocol, not native
full-resolution imagery. Forest/agriculture labels do not establish vegetation species.

### 03R: temporal change

- Transfers every legacy parameter, including the encoder, question encoder and answer head.
- Adds a feature-pyramid residual mask decoder using stride-4 features, rather than only enlarging
  the old stride-32 map. Zero initialization preserves parent predictions before new training.
- Encodes each image pair once for its group of questions. All training questions remain in use.
- Batch one/accumulation eight; frozen batch-normalization statistics; boundary-weighted BCE + Dice.
- No temporal reversal or crops that invalidate whole-scene questions. Spatial-language questions
  are excluded from rotations/flips.
- Strict real-pair forward/backward preflight, raw QA predictions and reversible mask records.
- Validation chooses weights; public test runs only after validation passes. Because you already
  inspected the old public test, new results are labelled **repeated public test**, not untouched.

This is still generic semantic change plus a closed-answer-vocabulary expert. It does not learn
flood causes, arbitrary long reports or reliable geographic attribution. The finer decoder creates
an opportunity to improve boundaries; it cannot restore detail absent from a 256px input.

### 04: optical/SAR flood

- Fixed TerraMind tiny profile, microbatch one, accumulation four, zero workers.
- Float32 loss reductions, nodata-safe loss, full optimizer/scaler recovery state.
- Pixel labels are real Sen1Floods11 hand labels, not pseudo-ground-truth from the model.
- Fused, optical-only and SAR-only validation ablations; test is gated behind validation success.
- The model predicts flood/water, not every land-cover class. Sentinel results do not prove
  Cartosat/RISAT or India-domain performance. Softmax values remain uncalibrated.

## If Kaggle stops

Each completed epoch refreshes a `*_resume.zip`. Download it when available and save notebook
outputs. A crash during the very first epoch may leave no new checkpoint. Timers target roughly
eight training hours, but data downloads, validation, export and an in-progress epoch add time;
the code cannot guarantee completion within the platform session limit.

In a fresh session:

1. Import the same recovery notebook.
2. Attach the latest **extracted resume ZIP** as a private Dataset/Notebook Output.
3. For 02R/03R, attach the original parent inference folder too.
4. Keep the Config cell unchanged and Run All. The experiment/profile must match.

Inference ZIPs are for serving; resume ZIPs contain optimizer state and are for continued training.
Preserve both. Save the current completed output; avoid starting another full training run merely
to save a version. Only load recovery checkpoints you produced yourself.

If final gates fail, preserve the predictions/history and review errors before another experiment.
Do not lower targets or repeatedly tune on public test results. The 03R repeated-test status means
an additional genuinely untouched external evaluation is needed for a strong generalization claim.

## Serving and Hugging Face

Use **06R**, not the older 06: its embedded temporal architecture matches 03R. Do not mix a legacy
03 artifact with this runtime. Attach only inference ZIP contents, not parent/resume backups.

Enable these Secrets for 06R only:

- `HF_TOKEN`: current Hugging Face read token.
- `NGROK_AUTHTOKEN`: your ngrok agent token.
- `SATQUERY_MODEL_SERVICE_TOKEN`: matches the local backend bearer token.

Do not put tokens into notebook source or exported files. Replace any old tokens exposed in chats
or screenshots. The attended tunnel remains time-limited by the notebook; it is not 24/7 hosting.

Training does not update your original Qwen repository. Each specialist is a separate checkpoint;
Kaggle input attachments are sufficient to serve them. A later explicit upload can publish each
accepted specialist separately, without overwriting the original Qwen LoRA.

## Verification scope

The pack generator checks all cell syntax and notebook schemas. Local tests cover artifact
discovery/checksums, recovery ZIP handling, acceptance rules and embedded runtime compatibility.
GPU preflights and full training/evaluation run in Kaggle, not on this laptop. No new quality
scores or CUDA runtime guarantees are claimed by generating these files.

Implementation references: [Transformers Trainer 4.57.1](https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/trainer),
[CDVQA authors](https://github.com/YZHJessica/CDVQA),
[Sen1Floods11 publisher](https://github.com/cloudtostreet/Sen1Floods11).
